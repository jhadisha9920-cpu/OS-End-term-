#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/wait.h>
int main(){
    pid_t pid = fork();
    if(pid<0){
        printf("Fork Failed");
        return(EXIT_FAILURE);
    }
    else if(pid == 0){
        printf("Child process terminating\n");
        exit(0);
    }
    else{
        printf("Parent sleeping...\n");
        sleep(30);
    }
    return 0;
}