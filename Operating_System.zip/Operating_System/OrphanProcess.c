#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/wait.h>
int main(){
    pid_t pid = fork();
    if(pid<0){
        printf("Fork Failed");
        return(EXIT_FAILURE);
    }
    else if(pid==0){
        printf("Child PID and Parent PID: %d %d\n",(int)getpid(), (int)getppid());
        sleep(10);
        printf("Child PID and Parent PID: %d %d ",(int)getpid(), (int)getppid());
    }
    else{
        printf("Parent process terminating\n");
        exit(0);
    }
    return 0;
}