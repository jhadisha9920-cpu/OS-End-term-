#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main(void)
{
    pid_t pid;
    pid_t terminated;

    pid = fork();

    if (pid < 0)
    {
        perror("fork failed");
        return EXIT_FAILURE;
    }
    else if (pid == 0)
    {
        printf("Child PID = %d\n", (int)getpid());
        exit(0);
    }
    else
    {
        terminated = wait(NULL);

        printf("PID returned by wait() = %d\n",
               (int)terminated);
    }

    return 0;
}