#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
int main(){
    int i,n=20;
    pid_t pid = fork();
    if(pid==0){
        for(int i=0;i<=20;i+=2){
            printf("%d",i);
        }
        printf("\n");
    }
    else if(pid>0){
        for(int i=1;i<=20;i+=2){
            printf("%d",i);
        }
        printf("\n");
    }
    else{
        printf("Fork Failed");
    }
    return 0;
}