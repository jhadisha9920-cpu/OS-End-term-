#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
int main(){
    pid_t pid = fork();
    if(pid==0){
        printf("Child Process\n");
    }
    else if(pid>0){
        printf("Parent Process\n");
    }
    else{
        printf("Fork Failed");
    }
}