#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
int main(){
    pid_t pid = fork();
    if(pid<0){
        printf("Fork Failed");
        return EXIT_FAILURE;
    }
    printf("LINUX\n");
    return EXIT_SUCCESS;
}