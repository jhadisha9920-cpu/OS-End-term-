#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main(void)
{
    pid_t pid;
    int status;

    pid = fork();

    if (pid < 0)
    {
        perror("fork failed");
        return EXIT_FAILURE;
    }
    else if (pid == 0)
    {
        sleep(2);

        printf("Child finished\n");

        exit(0);
    }
    else
    {
        printf("Parent is waiting for child\n");

        waitpid(pid, &status, 0);

        printf("Parent: Child has terminated\n");

        if (WIFEXITED(status))
        {
            printf("Child exit status = %d\n",
                   WEXITSTATUS(status));
        }
    }

    return 0;
}