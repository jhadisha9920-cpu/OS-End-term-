#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
int main(){
    pid_t pid = fork();
    if(pid==0){
        printf("Child Process\n");
        printf("Child PID = %d\n", (int)getpid());
        printf("Parent PID = %d\n", (int)getppid());
    }
    else if(pid >0){
        printf("Parent Process\n");
        printf("Child PID = %d\n", (int)getpid());
        printf("Parent PID = %d\n", (int)getppid());
    }
    else{
        printf("Fork Failed");
        return EXIT_FAILURE;
    }
}