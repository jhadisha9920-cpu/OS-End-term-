/* #include<stdio.h>
#include<stdlib.h>
#include<sys/wait.h>
#include<unistd.h>
int main(){
    pid_t pid = fork();
    if(pid<0){
        printf("Fork Failed");
        return EXIT_FAILURE;
    }
    else if(pid ==0){
        printf("I am Child\n");
        exit(0);
    }
    else{
        wait(NULL);
        printf("I am Parent");

    }
    return 0;
} */


#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main(void)
{
    pid_t pid = fork();

    if (pid < 0)
    {
        perror("fork failed");
        return EXIT_FAILURE;
    }
    else if (pid == 0)
    {
        printf("Child is executing\n");
        printf("Child PID = %d\n", (int)getpid());

        sleep(2);

        printf("Child has completed\n");
        exit(EXIT_SUCCESS);
    }
    else
    {
        printf("Parent is waiting for child...\n");

        wait(NULL);

        printf("Parent has completed waiting\n");
    }

    return 0;
}