#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/wait.h>
#include<string.h>
int main(){
    int p2c[2],c2p[2];
    int number,recieved,result;
    printf("Enter a number: ");
    scanf("%d",&number);
    pipe(p2c);
    pipe(c2p);
    pid_t pid = fork();
    if(pid<0){
        printf("Fork Failed");
        return EXIT_FAILURE;
    }
    else if(pid == 0){
        close(p2c[1]);
        close(c2p[0]);
        read(p2c[0],&recieved,sizeof(recieved));
        printf("Child Recieved: %d\n",recieved);
        result = recieved*recieved;
        write(c2p[1],&result,sizeof(result));
        close(p2c[0]);
        close(c2p[1]);
    }
    else{
        close(p2c[0]);
        close(c2p[1]);
        write(p2c[1],&number,sizeof(number));
        printf("Parent Sent: %d\n",number);
        read(c2p[0],&result,sizeof(result));
        printf("Parent recieved square: %d\n",result);
        close(p2c[1]);
        close(c2p[0]);
        wait(NULL);
    }
    return 0;
}