#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
int main(){
    pid_t pid = fork();  // creates child process
    if(pid < 0){
        printf("Fork Failed");
        return EXIT_FAILURE;
    }
    else if (pid ==0){
        printf("Child Process\n");
        printf("Child PID = %d\n", (int)getpid());
        printf("Parent PID = %d\n", (int)getppid());
    }
    else{
        printf("Parent Process\n");
        printf("Child PID = %d\n", (int)getpid());
        printf("Parent PID = %d\n", (int)getppid());
    }
}