#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/wait.h>
int main(){
     int n;
    printf("Enter the number: ");
    scanf("%d", &n);
    pid_t pid = fork();
    if(pid<0){
        printf("Fork Failed");
        return EXIT_FAILURE;
    }
    else if(pid==0){
         int fact=1;
        printf("Child Process\n");
        for(int i=1;i<=n;i++){
            fact = fact*i;
        }
        printf("Factorial of a number : %d\n",fact);
        exit(0);
    }
    else{
        wait(NULL);
        printf("Parent: Child Process completed its factorial calculation");
    }
    return 0;
}