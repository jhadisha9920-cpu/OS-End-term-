#include <stdio.h>
#include <unistd.h>

int main()
{
    int pid;

    pid = fork();

    printf("Process PID = %d, fork() returned = %d\n", getpid(), pid);

    return 0;
}