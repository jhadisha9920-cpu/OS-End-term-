/* #include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/wait.h>
#include<string.h>
int main(){
    int fd[2];
    char message[]="Hello from Child";
    char buffer[100];
    if(pipe(fd)==-1){
        perror("pipe");
        return EXIT_FAILURE;
    }
    pid_t pid = fork();
    if(pid<0){
        printf("Fork Failed");
        return EXIT_FAILURE;
     }
     if (pid == 0){
        close(fd[0]);
        write(fd[1],message,strlen(message)+1);
        close(fd[1]);
     }
     else{
        close(fd[1]);
        read(fd[0],buffer,sizeof(buffer));
        printf("Parent recieved: %s\n", buffer);
        close(fd[0]);
        wait(NULL);
     }
     return 0;
} */




/* #include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/wait.h>
#include<string.h>
int main(){
    int fd[2];
    char message[100];
    char buffer[100];
    if(pipe(fd)==-1){
        perror("pipe");
        return EXIT_FAILURE;
    }
    pid_t pid = fork();
    if(pid<0){
        printf("Fork Failed");
        return EXIT_FAILURE;
    }
    else if(pid==0){
        close(fd[0]);
        printf("Enter a String: ");
        fflush(stdout);
        fgets(message,sizeof(message),stdin);
        write(fd[1],message,strlen(message)+1);
        close(fd[1]);
        exit(EXIT_SUCCESS);
    }
    else{
        close(fd[1]);
        read(fd[0],buffer,sizeof(buffer));
        printf("Parent Recieved: %s\n", buffer);
        close(fd[0]);
        wait(NULL);
    }
    return 0;
} */




#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/wait.h>
int main(){
    int fd[2];
    //int number = 10;
    int number;
    if(pipe(fd)==-1){
        perror("Pipe");
        return 1;
    }
    pid_t pid = fork();
    if(pid<0){
        printf("Fork Failed");
        return EXIT_FAILURE;
    }
    else if(pid==0){
        int received;
        close(fd[1]);
        read(fd[0],&received,sizeof(received));
        printf("Child Recieved: %d\n",received);
        close(fd[0]);
        exit(EXIT_SUCCESS);
    }
    else{
        close(fd[0]);
        printf("Enter the number: ");
        scanf("%d",&number);
        write(fd[1],&number,sizeof(number));
        printf("Parent Sent: %d\n",number);
        close(fd[1]);
        wait(NULL);
    }
    return 0;
}