#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main(void)
{
    pid_t pid;
    pid_t terminated;

    for (int i = 1; i <= 3; i++)
    {
        pid = fork();

        if (pid < 0)
        {
            perror("fork failed");
            return EXIT_FAILURE;
        }

        if (pid == 0)
        {
            int sleep_time = i * 2;

            printf("Child %d: PID = %d, sleeping for %d seconds\n",
                   i, (int)getpid(), sleep_time);

            sleep(sleep_time);

            printf("Child %d: terminating\n", i);
            exit(0);
        }
    }

    // Parent waits for all three children
    for (int i = 1; i <= 3; i++)
    {
        terminated = wait(NULL);

        printf("Parent: Child with PID %d terminated\n",
               (int)terminated);
    }

    return 0;
}