#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main(void)
{
    pid_t pid1, pid2;
    pid_t terminated;

    pid1 = fork();

    if (pid1 < 0)
    {
        perror("fork failed");
        return EXIT_FAILURE;
    }
    else if (pid1 == 0)
    {
        printf("Child 1: PID = %d\n", (int)getpid());
        sleep(2);
        exit(0);
    }

    pid2 = fork();

    if (pid2 < 0)
    {
        perror("fork failed");
        return EXIT_FAILURE;
    }
    else if (pid2 == 0)
    {
        printf("Child 2: PID = %d\n", (int)getpid());
        sleep(1);
        exit(0);
    }

    terminated = wait(NULL);
    printf("Parent: Child with PID %d terminated\n",
           (int)terminated);

    terminated = wait(NULL);
    printf("Parent: Child with PID %d terminated\n",
           (int)terminated);

    return 0;
}