#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
int main(){
    fork();
    printf("LINUX\n");
    fork();
    printf("UNIX\n");
    fork();
    printf("RED HAT\n");
    
    return EXIT_SUCCESS;
}