#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/wait.h>
int main(){
    pid_t pid = fork();
    if(pid<0){
        printf("Fork Failed");
        return EXIT_FAILURE;
    }
    else if(pid==0){
        printf("Child Process: ");
        for(int i=1;i<=5;i++){
            printf("%d\n", i);
        }
        exit(0);
    }
    else{
        wait(NULL);
         printf("Parent Process: ");
        for(int i=6;i<=10;i++){
            printf("%d\n", i);
        }
    }
    return 0;
}