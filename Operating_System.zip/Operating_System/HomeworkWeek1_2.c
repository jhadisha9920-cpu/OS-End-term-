#include <stdio.h>
#include <unistd.h>

int main()
{
    for (int i = 1; i <= 3; i++)
    {
        pid_t pid = fork();

        if (pid == 0)
        {
            printf("Child %d\n", i);
            printf("PID: %d\n", getpid());
            printf("PPID: %d\n", getppid());

            return 0;
        }
    }

    return 0;
}