#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/wait.h>
int main(){
    pid_t pid = fork();
    int status;
    if(pid<0){
        printf("Fork Failed");
        return EXIT_FAILURE;
    }
    else if(pid == 0){
        printf("Child process exiting with status 10\n");
        exit(10);
    }
    else{
        wait(&status);
        printf("Parent: Child is terminated\n");
        if(WIFEXITED(status)){
            printf("Child exit Status = %d\n", WEXITSTATUS(status));
        }
    }
    return 0;
}